# Llama
Welcome to my Repo! :smile: This repository contains notebooks:
* That can be run on Google Colab to understand how to use Llama 2 models
* Examples of fine-tuning Llama 2 models with different datasets (you can)
* Prompt-engineering with open source tools/frameworks such as Langchain, FAISS, etc
* and other fun stuff you can do with Llama!
